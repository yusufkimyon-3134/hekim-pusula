﻿HEKIM PUSULA - Faydalı Oy Düzeltmesi

Bu paketin içindeki src klasörünü, proje klasörünün üzerine kopyalayın ve dosya değiştirme sorusuna Evet deyin.

Sonra VS Code terminalinde:

npm.cmd run build

Başarılı olursa güncellemeyi yayına göndermek için:

git add src/app/clinic/[id]/actions.ts src/app/clinic/[id]/page.tsx
git commit -m "Faydali oy geri bildirimini duzelt"
git push origin HEAD:main
